from pascal.main import PascalVOC, ParseException, PascalObject, BndBox, size_block
