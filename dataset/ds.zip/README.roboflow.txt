
Oranges3 - v1 2021-05-11 3:23pm
==============================

This dataset was exported via roboflow.ai on May 11, 2021 at 12:23 PM GMT

It includes 2214 images.
Orange are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 2 versions of each source image:
* Randomly crop between 0 and 67 percent of the image


